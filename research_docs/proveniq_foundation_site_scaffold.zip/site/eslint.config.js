export default [
  {
    ignores: ["dist/**", ".astro/**", "node_modules/**"],
    rules: {}
  }
];
