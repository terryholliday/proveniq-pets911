# ProvenIQ Foundation Site

## Goals
- Static, fast, accessible
- Copy rendered verbatim from `/content/*.md`
- Legal canon lives in `/docs/site-canon.md` (read-only)

## Setup
```bash
cd site
npm install
npm run dev
```

## Build
```bash
npm run build
npm run preview
```

## Domain Redirects
See `docs/REDIRECTS.md` for host-level redirect guidance:
- pro-found.org -> proveniqfoundation.org (301)
