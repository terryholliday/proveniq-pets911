import fs from 'node:fs';
import path from 'node:path';

export function loadMarkdown(slug: string): string {
  // Slug corresponds to a file in the repository root: /content/<slug>.md
  // We resolve relative to the monorepo root (one level above /site).
  const repoRoot = path.resolve(process.cwd(), '..');
  const filePath = path.join(repoRoot, 'content', `${slug}.md`);
  return fs.readFileSync(filePath, 'utf-8');
}
