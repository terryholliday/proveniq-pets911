# Global Workspace Rules — ProvenIQ Foundation Build

## Authority Split
- **Antigravity** is the sole authority for:
  - legal language
  - governance constraints
  - compliance boundaries
  - canonical copy text
  - schemas labeled "CANONICAL"

- **Windsurf** is strictly for execution:
  - implementation
  - rendering content verbatim
  - routing, accessibility, performance
  - deployment configs
  - tests and CI checks

## Read-Only Canon Law
The file `docs/site-canon.md` is READ-ONLY CANON LAW.
Windsurf must not rewrite copy or reinterpret constraints.
Any desired change must be requested from Antigravity as a canon update.

## Copy Handling Rule
All public copy must be stored in `/content/*.md` and rendered verbatim.
No legal copy is hardcoded directly into components.

## Safety Constraints (Non-negotiable)
Never add:
- cash prizes or cash equivalents
- "lottery" / "raffle" terminology
- guarantees
- regulator endorsement claims
- data sale or ad monetization language
- commercial upsells

## Link-Out Rule
Full Official Rules and canonical legal terms must live on proveniqtrust.org and be linked out.
The Foundation site may provide summaries only.

## Model Guidance
- Antigravity: start with the lowest-cost long-context model that reliably follows strict constraints; bump one tier only if it drifts.
- Windsurf: start with the lowest-cost coding model that can scaffold a static site and preserve text verbatim; bump one tier only if it starts "improving" copy.
