# ProvenIQ Foundation — Site Canon (v1.0)
**Authority:** Antigravity (Canonical)  
**Entity:** ProvenIQ Foundation (WV nonprofit; 501(c)(3) pending)  
**Public Brand Domain:** pro-found.org  
**Canonical / Compliance Domain:** proveniqfoundation.org  
**IP Holder:** ProvenIQ Charitable Trust (Wyoming Statutory Trust) — proveniqtrust.org  
**Classification:** Public-facing, regulator-safe, donor-safe, media-safe  
**Hard Rule:** Foundation does **not** own the software; it uses it under a charitable license from the Trust.

---

## 1) Canonical Site Map

### Required Pages
1. `/` — Home
2. `/how-it-works` — How the Foundation Works
3. `/trust-and-technology` — Trust & Technology Structure (separation + licensing)
4. `/programs/homeward-bound` — Homeward Bound Rewards™ overview (public explainer)
5. `/legal` — Legal & Disclosures (links out to Trust canonical documents)
6. `/contact` — Contact (no fundraising claims; basic contact form/email)

### Optional Pages (Only if approved later)
- `/impact` — Metrics & reporting (requires validated data pipeline)
- `/news` — Press releases (only if staffed)
- `/partners` — Sponsors/partners (only after sponsor contracts exist)

### Legally / Regulator-Sensitive Items (Must exist)
- Clear nonprofit disclosure (WV nonprofit; 501(c)(3) pending)
- Clear statement: Foundation does not own the software
- Clear statement: registry data is not sold
- Links to canonical legal pages on proveniqtrust.org:
  - Official Rules (Homeward Bound Rewards™)
  - Privacy Policy
  - Terms of Service
  - AMOE process (if applicable)

---

## 2) Page-by-Page Content Spec

### A) Home (`/`)
**Purpose:** High-level mission + safe entry points.  
**Allowed claims:** public-benefit framing; “encourages microchip registration and scanning”; “supports reunification outcomes.”  
**Forbidden language:** “guarantees,” “verified by regulators,” “state approved,” “lottery,” “win money,” “we sell data,” “we track people.”  
**Required disclaimers:** 501(c)(3) pending; no purchase necessary for sweepstakes (if referenced).

### B) How It Works (`/how-it-works`)
**Purpose:** Explain entity roles (Foundation vs Trust), and how programs are operated.  
**Allowed claims:** separation protects donors/mission; charitable programs are free; public reporting where available.  
**Forbidden:** any implication Foundation owns or can sell the code; any commercial upsell.  
**Required:** “Foundation uses Trust-owned software under a charitable license.”

### C) Trust & Technology (`/trust-and-technology`)
**Purpose:** Regulator-safe disclosure of the hybrid structure.  
**Allowed:** “Trust holds proprietary software and licenses it to the Foundation for charitable use.”  
**Forbidden:** trade secret details; repository names; security-through-obscurity claims.  
**Required:** explicit separation and “no sale of registry data.”

### D) Homeward Bound (`/programs/homeward-bound`)
**Purpose:** Public explainer of the program and benefits; link to official rules.  
**Allowed:** non-cash prize examples; gift card cap ($250); entries tied to protective actions; “no purchase or donation required.”  
**Forbidden:** “lottery,” “raffle,” any cash-equivalent prizes, prize guarantees, odds promises.  
**Required:** prominent link to Official Rules and Privacy.

### E) Legal (`/legal`)
**Purpose:** Disclosures and canonical links.  
**Allowed:** direct links to proveniqtrust.org legal docs; summary statements; contact for legal inquiries.  
**Forbidden:** hosting full sweepstakes rules locally (to prevent drift); custom paraphrases that conflict.  
**Required:** links to Privacy/Terms/Official Rules; nonprofit status disclosure.

### F) Contact (`/contact`)
**Purpose:** Legit contact pathway; press and regulator contact.  
**Allowed:** email, form, mailing address (optional).  
**Forbidden:** donation solicitations unless separately approved; promises of response times.

---

## 3) Core Copy (Final Form)

### Home — Headline
**Protecting Pets. Reuniting Families. Advancing Trust.**

### Home — Body
ProvenIQ Foundation is a West Virginia nonprofit corporation (501(c)(3) pending) operating public-benefit programs that encourage responsible microchip registration and scanning to improve lost-pet reunification outcomes.

We operate with clear safeguards:
- Nonprofit governance and public-benefit reporting
- No sale of registry data
- Transparent program rules
- Non-cash incentives only, where offered

### Home — CTAs
- Learn how it works
- Explore Homeward Bound Rewards™
- Legal & disclosures

---

### How the Foundation Works — Core Copy
ProvenIQ Foundation operates charitable programs that improve pet safety and reunification outcomes. The Foundation does not own the underlying software systems. Those systems are owned by ProvenIQ Charitable Trust (Wyoming) and are licensed to the Foundation for charitable purposes.

This separation exists to protect mission integrity, prevent commercialization of charitable operations, and ensure the long-term reliability of public-benefit programs.

---

### Trust & Technology — Core Copy
ProvenIQ Charitable Trust holds proprietary software and technical systems as protected intellectual property. ProvenIQ Foundation uses those systems under a charitable license restricted to charitable and educational purposes.

We do not sell registry data. Sponsors and partners do not receive access to personal registry records.

---

### Homeward Bound Rewards™ — Core Copy
Homeward Bound Rewards™ is a free program that encourages microchip registration and periodic scan confirmations. Eligible protective actions may earn entries into periodic drawings for non-cash pet-related prizes (e.g., pet supplies or gift cards capped at $250), subject to the Official Rules.

No purchase or donation is required to enter or win. Void where prohibited.

---

### Footer Disclosures (verbatim)
ProvenIQ Foundation is a West Virginia nonprofit corporation. 501(c)(3) status pending.  
Technology is owned by ProvenIQ Charitable Trust and licensed for charitable use.  
We do not sell registry data.

---

## 4) Compliance Constraints (Non-Negotiable)

### Must NEVER appear
- Cash prizes or cash equivalents
- “Lottery” or “raffle” terminology
- “Guaranteed reunification” or any guarantee language
- Claims of regulatory approval or endorsement
- Any data sale/monetization language
- Any commercial product marketing (Proveniq products, pricing, upsells)

### Must ALWAYS link out to proveniqtrust.org
- Official Rules (Homeward Bound Rewards™)
- Privacy Policy
- Terms of Service
- AMOE instructions (if used)
- Any legal definitions that affect participant rights

---

## 5) Handoff Contract for Implementation (Windsurf)

### Windsurf MAY
- Implement navigation, layout, accessibility, SEO, performance
- Create build/deploy configs
- Add analytics hooks only if approved and privacy-safe

### Windsurf MUST NOT
- Rewrite or paraphrase legal copy
- Add pages, claims, or fundraising language
- Host full Official Rules locally
- Create any cross-links to commercial Proveniq products

### Content Handling Requirement
All page copy must be sourced from versioned markdown files and rendered verbatim.
