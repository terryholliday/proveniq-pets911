# Domain Redirect Guidance (301)

Goal:
- `pro-found.org` -> `proveniqfoundation.org` (301, preserve path + query)

## Cloudflare (recommended)
1. Add both domains to Cloudflare.
2. Create a Redirect Rule:
   - If hostname equals `pro-found.org` or `www.pro-found.org`
   - Then URL redirect (301) to `https://proveniqfoundation.org/$1` with path preserved.

## Vercel
Vercel handles redirects best at the domain/cdn layer. Configure `pro-found.org` as an additional domain and set it to redirect to the primary domain in Vercel's domain settings.

## Netlify
Use Netlify domain settings to set `pro-found.org` as an alias and enable a 301 redirect to the primary domain.
