# Home

## Protecting Pets. Reuniting Families. Advancing Trust.

ProvenIQ Foundation is a West Virginia nonprofit corporation (501(c)(3) pending) operating public-benefit programs that encourage responsible microchip registration and scanning to improve lost-pet reunification outcomes.

We operate with clear safeguards:
- Nonprofit governance and public-benefit reporting
- No sale of registry data
- Transparent program rules
- Non-cash incentives only, where offered

## Get started
- Learn how it works
- Explore Homeward Bound Rewards™
- Legal & disclosures
