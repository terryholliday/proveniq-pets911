# Trust & Technology Structure

ProvenIQ Charitable Trust holds proprietary software and technical systems as protected intellectual property. ProvenIQ Foundation uses those systems under a charitable license restricted to charitable and educational purposes.

We do not sell registry data. Sponsors and partners do not receive access to personal registry records.

For canonical legal terms and program rules, see the Trust’s official disclosures.
