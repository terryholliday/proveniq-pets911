# Homeward Bound Rewards™

Homeward Bound Rewards™ is a free program that encourages microchip registration and periodic scan confirmations. Eligible protective actions may earn entries into periodic drawings for non-cash pet-related prizes (e.g., pet supplies or gift cards capped at $250), subject to the Official Rules.

No purchase or donation is required to enter or win. Void where prohibited.

## What this program is designed to do
- Increase microchip registration coverage
- Normalize periodic scan confirmations
- Improve reunification outcomes
- Produce public-benefit reporting data

## What it is not
- Not a lottery or raffle
- Not pay-to-play
- Not a cash-prize program
- Not a data monetization program
