# How the Foundation Works

ProvenIQ Foundation operates charitable programs that improve pet safety and reunification outcomes.

The Foundation does not own the underlying software systems. Those systems are owned by ProvenIQ Charitable Trust (Wyoming) and are licensed to the Foundation for charitable purposes.

This separation exists to protect mission integrity, prevent commercialization of charitable operations, and ensure the long-term reliability of public-benefit programs.
