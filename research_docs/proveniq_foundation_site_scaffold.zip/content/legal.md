# Legal & Disclosures

## Nonprofit status
ProvenIQ Foundation is a West Virginia nonprofit corporation. 501(c)(3) status pending.

## Technology ownership
Technology is owned by ProvenIQ Charitable Trust (Wyoming) and licensed for charitable use.

## Data practices
We do not sell registry data.

## Canonical legal documents (Trust)
- Official Rules (Homeward Bound Rewards™): https://proveniqtrust.org
- Privacy Policy: https://proveniqtrust.org/privacy
- Terms of Service: https://proveniqtrust.org/terms
- AMOE (if applicable): https://proveniqtrust.org/amoe

If any link is unavailable, contact us and we will provide the current canonical location.
